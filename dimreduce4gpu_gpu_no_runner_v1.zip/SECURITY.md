# Security Policy

## Reporting a vulnerability

Please report security issues by opening a GitHub issue with the label **security**.
If the issue is sensitive, please contact the maintainer listed in `pyproject.toml` via email.
